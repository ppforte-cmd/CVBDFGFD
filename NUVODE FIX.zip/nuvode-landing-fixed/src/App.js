import { useState, useEffect } from "react";

const useIsMobile = (bp = 768) => {
  const [m, setM] = useState(false);
  useEffect(() => {
    const check = () => setM(window.innerWidth <= bp);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, [bp]);
  return m;
};

const C = {
  navy: "#0A1628", navyL: "#1E293B", cyan: "#0099BB", cyanH: "#00829E", cyanBg: "#F0FBFD",
  bg: "#FFF", bg2: "#F8FAFC", bg3: "#F1F5F9", bdr: "#E2E8F0", bdrH: "#CBD5E1",
  tx: "#0F172A", tx2: "#334155", mid: "#64748B", dim: "#94A3B8",
  grn: "#10B981", grnBg: "#ECFDF5", pur: "#7C3AED", purBg: "#F5F3FF",
  org: "#F59E0B", orgBg: "#FFFBEB", pnk: "#EC4899", pnkBg: "#FDF2F8", red: "#EF4444",
};

// ===== SHARED =====
const Badge = ({ c = "cyan", children }) => {
  const m = { cyan: [C.cyanBg, C.cyan], purple: [C.purBg, C.pur], green: [C.grnBg, C.grn], orange: [C.orgBg, C.org], pink: [C.pnkBg, C.pnk] };
  const [bg, tx] = m[c];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 600, padding: "5px 14px", borderRadius: 20, background: bg, color: tx }}>{children}</span>;
};

const Btn = ({ primary, children, onClick, full }) => {
  const [h, setH] = useState(false);
  return <button onClick={onClick} onMouseOver={() => setH(true)} onMouseOut={() => setH(false)}
    style={{ fontFamily: "inherit", fontSize: 15, fontWeight: primary ? 600 : 500, color: primary ? "#FFF" : C.tx, background: primary ? (h ? C.cyanH : C.cyan) : "transparent", padding: "14px 28px", borderRadius: 12, border: primary ? "none" : `1px solid ${C.bdr}`, cursor: "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8, transition: "all 0.2s", transform: primary && h ? "translateY(-1px)" : "none", width: full ? "100%" : "auto" }}>{children}</button>;
};

const Ghost = ({ children, onClick }) => <button onClick={onClick} style={{ fontFamily: "inherit", fontSize: 15, fontWeight: 500, color: C.tx, background: "none", border: "none", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6, padding: "14px 8px" }}>{children}</button>;

const Sec = ({ alt, children, style, mob }) => <section style={{ padding: mob ? "60px 0" : "100px 0", background: alt ? C.bg2 : C.bg, borderTop: alt ? `1px solid ${C.bdr}` : "none", borderBottom: alt ? `1px solid ${C.bdr}` : "none", ...style }}><div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px" }}>{children}</div></section>;

const SH = ({ children }) => <div style={{ textAlign: "center", marginBottom: 48 }}>{children}</div>;
const H2 = ({ children, mob }) => <h2 style={{ fontSize: mob ? 28 : 36, fontWeight: 800, color: C.tx, letterSpacing: -1, marginBottom: 12, lineHeight: 1.15 }}>{children}</h2>;
const SP = ({ children }) => <p style={{ fontSize: 16, color: C.mid, maxWidth: 500, margin: "0 auto", lineHeight: 1.7 }}>{children}</p>;

const FC = ({ icon, bg, name, desc }) => <div style={{ background: C.bg, border: `1px solid ${C.bdr}`, borderRadius: 16, padding: "28px 24px" }}><div style={{ width: 42, height: 42, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16, fontSize: 18, background: bg }}>{icon}</div><div style={{ fontSize: 16, fontWeight: 700, color: C.tx, marginBottom: 8 }}>{name}</div><div style={{ fontSize: 14, color: C.mid, lineHeight: 1.6 }}>{desc}</div></div>;

const Chk = ({ c = "cyan", children }) => {
  const m = { cyan: [C.cyanBg, C.cyan], purple: [C.purBg, C.pur], green: [C.grnBg, C.grn] };
  const [bg, tx] = m[c];
  return <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 14, fontWeight: 500, color: C.tx2 }}><span style={{ width: 22, height: 22, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, background: bg, color: tx, flexShrink: 0 }}>✓</span>{children}</div>;
};

const ZC = ({ title, children }) => <div style={{ background: C.bg2, border: `1px solid ${C.bdr}`, borderRadius: 18, padding: 28 }}>{title && <div style={{ fontSize: 14, fontWeight: 600, color: C.tx, marginBottom: 16 }}>{title}</div>}{children}</div>;

const PH = ({ badge, bc, h1, span, sub, actions, mob, blobs = [] }) => (
  <div style={{ padding: mob ? "120px 0 60px" : "150px 0 80px", textAlign: "center", position: "relative", overflow: "hidden" }}>
    {blobs.map((b, i) => <div key={i} style={{ position: "absolute", borderRadius: "50%", pointerEvents: "none", ...b }} />)}
    <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px", position: "relative", zIndex: 1 }}>
      {badge && <div style={{ marginBottom: 20 }}><Badge c={bc}>{badge}</Badge></div>}
      <h1 style={{ fontSize: mob ? 32 : 52, fontWeight: 800, color: C.tx, letterSpacing: -1.5, lineHeight: 1.08, marginBottom: 18, maxWidth: 700, marginLeft: "auto", marginRight: "auto" }}>{h1} {span && <span style={{ color: C.cyan }}>{span}</span>}</h1>
      <p style={{ fontSize: mob ? 15 : 18, color: C.mid, maxWidth: 540, margin: "0 auto 32px", lineHeight: 1.7 }}>{sub}</p>
      {actions && <div style={{ display: "flex", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>{actions}</div>}
    </div>
  </div>
);

const CTA = ({ h2, sub, actions, mob }) => (
  <section style={{ padding: mob ? "60px 0" : "100px 0", textAlign: "center", background: C.bg2, borderTop: `1px solid ${C.bdr}` }}>
    <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px" }}>
      <h2 style={{ fontSize: mob ? 28 : 38, fontWeight: 800, color: C.tx, letterSpacing: -1, marginBottom: 14, lineHeight: 1.15 }}>{h2}</h2>
      <p style={{ fontSize: mob ? 15 : 17, color: C.mid, maxWidth: 440, margin: "0 auto 32px", lineHeight: 1.7 }}>{sub}</p>
      <div style={{ display: "flex", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>{actions}</div>
    </div>
  </section>
);

const NL = ({ s = 28 }) => <svg width={s} height={s} viewBox="0 0 100 100"><rect x="6" y="6" width="88" height="88" rx="20" fill="#0A1628" /><path d="M26 74V26h12l20 28V26h12v48H58L38 46v28H26z" fill="#FFF" /></svg>;

// Zigzag row helper
const ZZ = ({ mob, badge, bc, h3, p, checks, cc, visual, reverse, link }) => (
  <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "1fr 1fr", gap: mob ? 40 : 80, alignItems: "center", marginBottom: mob ? 60 : 100 }}>
    <div style={!mob && reverse ? { order: 2 } : {}}>
      <div style={{ marginBottom: 16 }}><Badge c={bc}>{badge}</Badge></div>
      <h3 style={{ fontSize: mob ? 24 : 30, fontWeight: 800, color: C.tx, marginBottom: 14, lineHeight: 1.2 }}>{h3}</h3>
      <p style={{ fontSize: mob ? 14 : 16, color: C.mid, lineHeight: 1.7, marginBottom: 24 }}>{p}</p>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>{checks.map(f => <Chk key={f} c={cc}>{f}</Chk>)}</div>
      {link && <div style={{ marginTop: 24 }}>{link}</div>}
    </div>
    <div style={!mob && reverse ? { order: 1 } : {}}>{visual}</div>
  </div>
);

// Viz helper
const Viz = ({ mob, title, icon, color, checklist }) => (
  <div style={{ background: C.bg, border: `1px solid ${C.bdr}`, borderRadius: 20, padding: mob ? 24 : 40, textAlign: "center" }}>
    <div style={{ width: 64, height: 64, borderRadius: 16, background: color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, margin: "0 auto 20px" }}>{icon}</div>
    <div style={{ fontSize: mob ? 20 : 24, fontWeight: 800, color: C.tx, marginBottom: 16 }}>{title}</div>
    <div style={{ display: "flex", flexDirection: "column", gap: 12, alignItems: "flex-start" }}>{checklist.map(i => <Chk key={i}>{i}</Chk>)}</div>
  </div>
);

// ===== PAGES =====

// HOME
const Home = ({ go, mob }) => (<>
  <PH mob={mob} badge="All-In-One Marketing Software" bc="cyan" h1="Your marketing team in" span="one platform." sub="CRM, automation, AI, and everything you need to acquire, manage, and grow your customer base. Built for African SMBs." actions={<><Btn primary onClick={() => go("pricing")}>Start free trial →</Btn><Btn onClick={() => go("crm")}>Explore features</Btn></>} blobs={[{ width: 300, height: 300, background: "rgba(0, 153, 187, 0.08)", top: -100, right: -50 }, { width: 200, height: 200, background: "rgba(124, 58, 237, 0.06)", bottom: 100, left: -20 }]} />

  <Sec mob={mob}>
    <SH><H2 mob={mob}>Why Nuvode.</H2><SP>Built for African SMBs. Priced for growth.</SP></SH>
    <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "repeat(3,1fr)", gap: mob ? 24 : 32 }}>
      <FC icon="🚀" bg={C.cyanBg} name="Fast setup" desc="Go from zero to automated in hours, not weeks. No coding required." />
      <FC icon="💰" bg={C.grnBg} name="Affordable" desc="$99/month for everything. No per-user fees, no surprise charges." />
      <FC icon="🤖" bg={C.purBg} name="AI-powered" desc="Your own AI employee. Vode handles follow-ups, emails, and more." />
      <FC icon="🌍" bg={C.orgBg} name="Africa-first" desc="Built for Uganda, Nigeria, and across Africa. Pay in local currency." />
      <FC icon="📱" bg={C.pnkBg} name="Mobile-ready" desc="Your CRM in your pocket. Manage customers on the go." />
      <FC icon="🔗" bg={C.cyanBg} name="Deep integrations" desc="Connect Stripe, WhatsApp, Slack, Zapier, and 100+ more tools." />
    </div>
  </Sec>

  <Sec mob={mob} alt>
    <ZZ mob={mob} badge="CRM" bc="cyan" h3="The CRM your customers actually use." p="Most CRM products are built for enterprises. Nuvode is built for you—simple, visual, and no enterprise nonsense." checks={["360° customer view", "Deal pipelines you control", "Mobile app included", "Automated follow-ups"]} cc="cyan" reverse visual={<div style={{ height: mob ? 240 : 360, background: C.cyanBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 60 : 100 }}>📊</div>} link={<Btn onClick={() => go("crm")}>Explore CRM →</Btn>} />
  </Sec>

  <Sec mob={mob}>
    <ZZ mob={mob} badge="Automation" bc="purple" h3="Work less. Earn more." p="Set it once, it runs forever. Email sequences, lead scoring, SMS campaigns, payment collection—all on autopilot." checks={["50+ pre-built workflows", "Conditional logic", "Zapier & n8n integration", "No per-automation fees"]} cc="purple" visual={<div style={{ height: mob ? 240 : 360, background: C.purBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 60 : 100 }}>⚡</div>} link={<Btn onClick={() => go("automation")}>Explore automation →</Btn>} />
  </Sec>

  <Sec mob={mob} alt>
    <ZZ mob={mob} badge="AI Employee" bc="green" h3="Meet Vode. Your AI team member." p="Vode is an autonomous AI agent built into Nuvode. It handles emails, follow-ups, customer support, and lead scoring. 24/7." checks={["Autonomous lead follow-up", "Email and SMS responses", "Customer support agent", "Always learning"]} cc="green" reverse visual={<div style={{ height: mob ? 240 : 360, background: C.grnBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 60 : 100 }}>🤖</div>} link={<Btn onClick={() => go("vode")}>Meet Vode →</Btn>} />
  </Sec>

  <Sec mob={mob}>
    <SH><H2 mob={mob}>How it works.</H2><SP>Nuvode in 3 steps.</SP></SH>
    <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "repeat(3,1fr)", gap: mob ? 24 : 32 }}>
      <Viz mob={mob} icon="1️⃣" title="Connect" color={C.cyanBg} checklist={["Link your email", "Connect payment tools", "Import your contacts"]} />
      <Viz mob={mob} icon="2️⃣" title="Automate" color={C.purBg} checklist={["Build workflows", "Set your rules", "Let Vode learn"]} />
      <Viz mob={mob} icon="3️⃣" title="Grow" color={C.grnBg} checklist={["Track performance", "Optimize campaigns", "Scale revenue"]} />
    </div>
  </Sec>

  <Sec mob={mob} alt>
    <SH><H2 mob={mob}>Loved by SMBs across Africa.</H2><SP>From freelancers to agencies—teams trust Nuvode to run their business.</SP></SH>
    <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "repeat(3,1fr)", gap: 24, marginBottom: 0 }}>
      {[
        { n: "Sarah M.", r: "Digital Agency Owner, Kampala", q: "Nuvode cut my admin time in half. I spend more time on strategy, less time on spreadsheets." },
        { n: "James O.", r: "E-commerce founder, Lagos", q: "The automation features alone are worth it. Our email revenue increased 3x in 90 days." },
        { n: "Aisha K.", r: "Freelance marketer, Accra", q: "Finally a CRM that doesn't feel like overkill. Simple, powerful, affordable." },
      ].map(t => (
        <div key={t.n} style={{ background: C.bg2, border: `1px solid ${C.bdr}`, borderRadius: 16, padding: 24 }}>
          <div style={{ fontSize: 13, color: C.dim, marginBottom: 12 }}>⭐⭐⭐⭐⭐</div>
          <div style={{ fontSize: 15, color: C.mid, lineHeight: 1.7, marginBottom: 16 }}>"{t.q}"</div>
          <div style={{ fontSize: 14, fontWeight: 600, color: C.tx }}>{t.n}</div>
          <div style={{ fontSize: 13, color: C.dim }}>{t.r}</div>
        </div>
      ))}
    </div>
  </Sec>

  <CTA mob={mob} h2="Ready to grow smarter?" sub="Start your 14-day free trial. CRM, automation, and AI — all in one platform." actions={<Btn primary onClick={() => go("pricing")}>Start free trial →</Btn>} />
</>);

// CRM PAGE
const CRM = ({ mob }) => (<>
  <PH mob={mob} badge="CRM" bc="cyan" h1="Your customer database." span="Simplified." sub="No enterprise bloat. Just a powerful, simple CRM built for teams that actually want to use it." />
  <Sec mob={mob}>
    <ZZ mob={mob} badge="Contacts" bc="cyan" h3="Every customer, one view." p="360° customer profiles with all their interactions, deals, communication history, and notes." checks={["Custom fields", "Bulk operations", "Auto-enrichment", "Contact lists"]} cc="cyan" visual={<div style={{ height: mob ? 240 : 320, background: C.cyanBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 50 : 80 }}>👥</div>} />
  </Sec>
  <Sec mob={mob} alt>
    <ZZ mob={mob} badge="Deals" bc="cyan" h3="Pipeline you control." p="Drag-and-drop deals. Custom stages. See exactly where money is." checks={["Unlimited pipelines", "Deal automation", "Forecasting", "Activity tracking"]} cc="cyan" reverse visual={<div style={{ height: mob ? 240 : 320, background: C.cyanBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 50 : 80 }}>📈</div>} />
  </Sec>
  <CTA mob={mob} h2="Ready to simplify your CRM?" sub="Start your 14-day free trial and see the difference." actions={<Btn primary>Start free trial →</Btn>} />
</>);

// AUTOMATION PAGE
const Auto = ({ mob }) => (<>
  <PH mob={mob} badge="Automation" bc="purple" h1="Stop doing repetitive work." span="Forever." sub="50+ pre-built workflows. Zapier & n8n integration. Your entire business on autopilot." />
  <Sec mob={mob}>
    <ZZ mob={mob} badge="Workflows" bc="purple" h3="No coding required." p="Build complex workflows with a visual editor. If this, then that. Conditional logic. Multi-step journeys." checks={["Visual builder", "50+ templates", "Conditional branching", "Error handling"]} cc="purple" visual={<div style={{ height: mob ? 240 : 320, background: C.purBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 50 : 80 }}>🔄</div>} />
  </Sec>
  <Sec mob={mob} alt>
    <ZZ mob={mob} badge="Integrations" bc="purple" h3="Your tools, all connected." p="Stripe, Zapier, Slack, Gmail, WhatsApp, Shopify, n8n, Segment—and 100+ more." checks={["Zapier integration", "n8n integration", "Webhooks", "Custom APIs"]} cc="purple" reverse visual={<div style={{ height: mob ? 240 : 320, background: C.purBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 50 : 80 }}>🔗</div>} />
  </Sec>
  <CTA mob={mob} h2="Automate your business today." sub="Start your 14-day free trial and unlock unlimited workflows." actions={<Btn primary>Start free trial →</Btn>} />
</>);

// VODE PAGE
const Vode = ({ mob }) => (<>
  <PH mob={mob} badge="AI Employee" bc="green" h1="Meet Vode." span="Your AI cofounder." sub="An autonomous AI agent that handles emails, follow-ups, customer support, and lead scoring—24/7. No prompts required." />
  <Sec mob={mob}>
    <ZZ mob={mob} badge="AI Employee" bc="green" h3="Works like a real person." p="Vode learns your business, your tone, your process. It doesn't follow scripts—it thinks." checks={["Learns your process", "Writes in your voice", "Makes decisions", "Handles objections"]} cc="green" visual={<div style={{ height: mob ? 240 : 320, background: C.grnBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 50 : 80 }}>🧠</div>} />
  </Sec>
  <Sec mob={mob} alt>
    <ZZ mob={mob} badge="What Vode Does" bc="green" h3="Everything you're still doing manually." p="Lead follow-up. Customer support. Email triage. Contract summaries. Proposal drafts. Meeting scheduling." checks={["Follow up leads", "Support inquiries", "Write emails", "Schedule meetings"]} cc="green" reverse visual={<div style={{ height: mob ? 240 : 320, background: C.grnBg, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 50 : 80 }}>⚙️</div>} />
  </Sec>
  <CTA mob={mob} h2="Hire your AI cofounder." sub="Start your 14-day free trial and watch Vode transform your business." actions={<Btn primary>Start free trial →</Btn>} />
</>);

// PRICING PAGE
const Pricing = ({ mob }) => (<>
  <PH mob={mob} badge="Simple Pricing" bc="cyan" h1="One plan. Everything included." span="No surprises." sub="$99/month for unlimited users, unlimited contacts, unlimited everything. Cancel anytime." />
  <Sec mob={mob}>
    <div style={{ maxWidth: 500, margin: "0 auto" }}>
      <ZC title="Nuvode Pro">
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 48, fontWeight: 800, color: C.tx }}>$99<span style={{ fontSize: 20, fontWeight: 600, color: C.mid }}>/mo</span></div>
          <div style={{ fontSize: 14, color: C.mid, marginTop: 6 }}>Billed monthly. Cancel anytime.</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 28 }}>
          <Chk c="cyan">Unlimited users & contacts</Chk>
          <Chk c="cyan">CRM with custom fields</Chk>
          <Chk c="cyan">50+ automation workflows</Chk>
          <Chk c="cyan">AI email & SMS sequences</Chk>
          <Chk c="cyan">Vode AI employee</Chk>
          <Chk c="cyan">Zapier & n8n integration</Chk>
          <Chk c="cyan">WhatsApp & SMS</Chk>
          <Chk c="cyan">24/7 email support</Chk>
        </div>
        <Btn primary full>Start free trial →</Btn>
      </ZC>
    </div>
    <div style={{ textAlign: "center", marginTop: 40 }}>
      <p style={{ fontSize: 14, color: C.mid }}>14-day free trial. No credit card required.<br />Email support included. Upgrade anytime.</p>
    </div>
  </Sec>
  <CTA mob={mob} h2="Start your free trial today." sub="14 days. Full access. No credit card required." actions={<Btn primary>Get started →</Btn>} />
</>);

// ABOUT PAGE
const About = ({ mob }) => (<>
  <PH mob={mob} badge="About" bc="cyan" h1="Building the marketing OS" span="for Africa." sub="Nuvode was built because African SMBs deserved better. Better tools. Better pricing. Better support." />
  <Sec mob={mob}>
    <SH><H2 mob={mob}>Our mission.</H2><SP>Empower 100,000 African SMBs to scale their business with technology they can actually afford and understand.</SP></SH>
  </Sec>
  <Sec mob={mob} alt>
    <div style={{ maxWidth: 700, margin: "0 auto" }}>
      <h3 style={{ fontSize: mob ? 22 : 28, fontWeight: 800, color: C.tx, marginBottom: 16, lineHeight: 1.2 }}>Why we built Nuvode.</h3>
      <p style={{ fontSize: mob ? 14 : 16, color: C.mid, lineHeight: 1.8, marginBottom: 20 }}>We watched thousands of small businesses across Kampala, Lagos, and beyond struggle with the same problems: juggling spreadsheets, losing leads, unable to automate, and paying enterprise prices for tools built for enterprises.</p>
      <p style={{ fontSize: mob ? 14 : 16, color: C.mid, lineHeight: 1.8, marginBottom: 20 }}>We decided to build something different. A tool built *for* African SMBs, not adapted to them. Priced for growth. Simple enough to use on day one. Powerful enough to scale with you.</p>
      <p style={{ fontSize: mob ? 14 : 16, color: C.mid, lineHeight: 1.8 }}>Nuvode is your marketing OS. Your CRM. Your automation engine. Your AI employee. All in one place. All for $99/month.</p>
    </div>
  </Sec>
  <CTA mob={mob} h2="Join thousands of SMBs using Nuvode." sub="Start your 14-day free trial today." actions={<Btn primary>Get started →</Btn>} />
</>);

// CONTACT PAGE
const Contact = ({ mob }) => (<>
  <PH mob={mob} badge="Contact" bc="cyan" h1="Get in touch." span="We're here." sub="Have a question? Want a demo? Let's chat." />
  <Sec mob={mob} style={{ paddingTop: 0 }}>
    <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "1fr 1fr", gap: mob ? 32 : 60, alignItems: "start" }}>
      <div><h3 style={{ fontSize: mob ? 20 : 24, fontWeight: 800, color: C.tx, marginBottom: 12 }}>Get in touch.</h3><p style={{ fontSize: mob ? 14 : 16, color: C.mid, lineHeight: 1.7, marginBottom: 32 }}>Fill out the form and our team will get back to you within 24 hours. Or reach us directly.</p>
        {[["📧", C.cyanBg, "Email us", "hello@nuvode.com"], ["💬", C.grnBg, "Sales inquiries", "grow@nuvode.com"], ["🤝", C.purBg, "Partnerships", "partners@nuvode.com"], ["🛟", C.orgBg, "Support", "support@nuvode.com"]].map(([ic, bg, lb, vl]) => <div key={lb} style={{ display: "flex", gap: 14, marginBottom: 24 }}><div style={{ width: 44, height: 44, borderRadius: 12, background: bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{ic}</div><div><div style={{ fontSize: 12, color: C.dim }}>{lb}</div><div style={{ fontSize: 15, fontWeight: 600, color: C.tx }}>{vl}</div></div></div>)}</div>
      <div style={{ background: C.bg, border: `1px solid ${C.bdr}`, borderRadius: 18, padding: mob ? 20 : 32 }}>
        <div style={{ fontSize: 18, fontWeight: 700, color: C.tx, marginBottom: 24 }}>Send us a message</div>
        <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "1fr 1fr", gap: 16, marginBottom: 16 }}>{["First name", "Last name"].map(l => <div key={l}><label style={{ display: "block", fontSize: 13, fontWeight: 600, color: C.tx, marginBottom: 6 }}>{l}</label><input style={{ width: "100%", fontFamily: "inherit", fontSize: 14, padding: "12px 16px", border: `1px solid ${C.bdr}`, borderRadius: 10, outline: "none" }} /></div>)}</div>
        {["Email", "Company"].map(l => <div key={l} style={{ marginBottom: 16 }}><label style={{ display: "block", fontSize: 13, fontWeight: 600, color: C.tx, marginBottom: 6 }}>{l}</label><input style={{ width: "100%", fontFamily: "inherit", fontSize: 14, padding: "12px 16px", border: `1px solid ${C.bdr}`, borderRadius: 10, outline: "none" }} /></div>)}
        <div style={{ marginBottom: 16 }}><label style={{ display: "block", fontSize: 13, fontWeight: 600, color: C.tx, marginBottom: 6 }}>Message</label><textarea rows={4} style={{ width: "100%", fontFamily: "inherit", fontSize: 14, padding: "12px 16px", border: `1px solid ${C.bdr}`, borderRadius: 10, outline: "none", resize: "vertical" }} /></div>
        <Btn primary full>Send message →</Btn>
      </div>
    </div>
  </Sec>
</>);

// BLOG PAGE
const Blog = ({ mob }) => {
  const [cat, setCat] = useState("All");
  const posts = [
    ["📊", C.cyanBg, "CRM", "cyan", "5 CRM mistakes that are costing you deals.", "Most small businesses use their CRM wrong. Here are the five most common mistakes — and how to fix them today.", "5 min", "Mar 10, 2026"],
    ["⚡", C.purBg, "Automation", "purple", "The 7 email automations every business needs.", "These seven workflows run on autopilot and generate revenue while you sleep. Set them up once and forget them.", "6 min", "Mar 8, 2026"],
    ["🚀", C.orgBg, "Growth", "orange", "From 0 to 1,000 leads in 90 days.", "A step-by-step playbook for generating your first thousand leads using only organic strategies and smart automation.", "10 min", "Mar 5, 2026"],
    ["🤖", C.grnBg, "AI", "green", "AI won't replace your team. It will make them unstoppable.", "The real value of AI isn't replacing people — it's giving every team member superpowers. Here's how.", "7 min", "Mar 2, 2026"],
    ["📱", C.pnkBg, "Product", "pink", "Introducing Vode — your AI employee inside Nuvode.", "Today we're launching Vode, an autonomous AI agent that handles lead follow-up, email, and CRM management.", "4 min", "Feb 28, 2026"],
    ["💡", C.cyanBg, "CRM", "cyan", "The complete guide to lead scoring for small businesses.", "Not all leads are equal. Learn how to score, prioritize, and focus on the ones most likely to convert.", "9 min", "Feb 24, 2026"],
  ];
  const cats = ["All", "CRM", "Automation", "AI", "Growth", "Product"];
  const filtered = cat === "All" ? posts : posts.filter(p => p[2] === cat);
  return (<>
    <PH mob={mob} badge="Blog" bc="purple" h1="Insights for" span="growth." sub="Strategies, tactics, and thinking on CRM, automation, AI, and building a business that grows itself." />
    <Sec mob={mob} style={{ paddingTop: 0 }}>
      {/* Featured */}
      <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "1fr 1fr", gap: mob ? 24 : 40, alignItems: "center", marginBottom: 48, padding: mob ? 24 : 40, background: C.bg2, border: `1px solid ${C.bdr}`, borderRadius: 20 }}>
        <div style={{ height: mob ? 160 : 240, borderRadius: 14, background: C.grnBg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 40 : 60 }}>🤖</div>
        <div>
          <div style={{ marginBottom: 14 }}><Badge c="green">AI & Automation</Badge></div>
          <div style={{ fontSize: mob ? 22 : 28, fontWeight: 800, color: C.tx, lineHeight: 1.2, marginBottom: 12 }}>Why your next hire should be an AI employee.</div>
          <div style={{ fontSize: mob ? 14 : 15, color: C.mid, lineHeight: 1.7, marginBottom: 16 }}>The average small business spends 40% of their time on repetitive tasks that AI can handle today. Here's how to make the shift — and why Vode changes the game.</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: C.dim }}>
            <span style={{ width: 28, height: 28, borderRadius: "50%", background: C.bg3, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: C.mid }}>N</span>
            Nuvode Team · 8 min · Mar 12, 2026
          </div>
        </div>
      </div>
      {/* Category tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 32, flexWrap: "wrap" }}>
        {cats.map(c => <button key={c} onClick={() => setCat(c)} style={{ fontFamily: "inherit", fontSize: 13, fontWeight: 500, padding: "8px 18px", borderRadius: 24, border: `1px solid ${cat === c ? C.navy : C.bdr}`, background: cat === c ? C.navy : C.bg, color: cat === c ? "#FFF" : C.mid, cursor: "pointer", transition: "all 0.2s" }}>{c}</button>)}
      </div>
      {/* Post grid */}
      <div style={{ display: "grid", gridTemplateColumns: mob ? "1fr" : "repeat(3,1fr)", gap: 20 }}>
        {filtered.map(([ic, bg, tg, tc, ti, ex, rd, dt]) => (
          <div key={ti} style={{ background: C.bg, border: `1px solid ${C.bdr}`, borderRadius: 16, overflow: "hidden", cursor: "pointer", transition: "all 0.2s" }}
            onMouseOver={e => { e.currentTarget.style.borderColor = C.bdrH; e.currentTarget.style.transform = "translateY(-2px)"; }}
            onMouseOut={e => { e.currentTarget.style.borderColor = C.bdr; e.currentTarget.style.transform = "none"; }}>
            <div style={{ height: mob ? 120 : 160, background: bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mob ? 28 : 40 }}>{ic}</div>
            <div style={{ padding: mob ? 16 : 24 }}>
              <div style={{ marginBottom: 10 }}><Badge c={tc}>{tg}</Badge></div>
              <div style={{ fontSize: mob ? 15 : 17, fontWeight: 700, color: C.tx, marginBottom: 8, lineHeight: 1.3 }}>{ti}</div>
              <div style={{ fontSize: 13, color: C.mid, lineHeight: 1.6, marginBottom: 16 }}>{ex}</div>
              <div style={{ fontSize: 12, color: C.dim }}>{rd} · {dt}</div>
            </div>
          </div>
        ))}
      </div>
      {filtered.length === 0 && <div style={{ textAlign: "center", padding: 60, color: C.dim }}>No posts in this category yet. Check back soon.</div>}
    </Sec>
    <CTA mob={mob} h2="Ready to grow smarter?" sub="Start your 14-day free trial. CRM, automation, and AI — all in one platform." actions={<Btn primary>Start free trial →</Btn>} />
  </>);
};

// NAV
const Nav = ({ page, go, mob }) => (
  <nav style={{ padding: mob ? "16px 0" : "20px 0", borderBottom: `1px solid ${C.bdr}`, position: "sticky", top: 0, background: C.bg, zIndex: 100 }}>
    <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <button onClick={() => go("home")} style={{ display: "flex", alignItems: "center", gap: 8, background: "none", border: "none", cursor: "pointer", padding: 0 }}><NL /> Nuvode</button>
      {mob ? <button style={{ fontFamily: "inherit", fontSize: 18, background: "none", border: "none", cursor: "pointer" }}>☰</button> : <div style={{ display: "flex", gap: 32 }}>
        {["CRM", "Automation", "Vode", "Pricing", "Blog", "About", "Contact"].map(l => <Ghost key={l} onClick={() => go(l.toLowerCase())}>{l}</Ghost>)}
      </div>}
    </div>
  </nav>
);

// FOOTER
const Foot = ({ go, mob }) => (
  <footer style={{ padding: mob ? "60px 0 40px" : "80px 0 60px", background: C.navy, color: "#FFF", borderTop: `1px solid ${C.navyL}` }}>
    <div style={{ maxWidth: 1140, margin: "0 auto", padding: "0 24px", display: "grid", gridTemplateColumns: mob ? "1fr" : "repeat(4,1fr)", gap: mob ? 40 : 60, marginBottom: 40 }}>
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20 }}><NL s={24} /> Nuvode</div>
        <p style={{ fontSize: 14, color: "#B0C4DE", lineHeight: 1.7 }}>All-in-one marketing software for African SMBs.</p>
      </div>
      {[["Product", ["CRM", "Automation", "Vode"]], ["Company", ["About", "Blog", "Contact"]], ["Legal", ["Privacy", "Terms", "Security"]]].map(([h, ls]) => <div key={h}><div style={{ fontWeight: 600, marginBottom: 16, fontSize: 13 }}>{h}</div><div style={{ display: "flex", flexDirection: "column", gap: 10 }}>{ls.map(l => <Ghost key={l} onClick={() => go(l.toLowerCase())} style={{ color: "#B0C4DE" }}>{l}</Ghost>)}</div></div>)}
    </div>
    <div style={{ borderTop: `1px solid ${C.navyL}`, paddingTop: 24, textAlign: "center", fontSize: 12, color: "#94A3B8" }}>© 2026 Nuvode. All rights reserved.</div>
  </footer>
);

// ===== APP =====
export default function App() {
  const [pg, setPg] = useState("home");
  const mob = useIsMobile();
  const go = (p) => { setPg(p); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const pages = { home: <Home go={go} mob={mob} />, crm: <CRM mob={mob} />, automation: <Auto mob={mob} />, vode: <Vode mob={mob} />, pricing: <Pricing mob={mob} />, about: <About mob={mob} />, contact: <Contact mob={mob} />, blog: <Blog mob={mob} /> };
  return (
    <div style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif", background: C.bg, minHeight: "100vh" }}>
      <Nav page={pg} go={go} mob={mob} />
      <main key={pg} style={{ animation: "fadeIn 0.3s ease" }}>{pages[pg]}</main>
      <Foot go={go} mob={mob} />
      <style>{`@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}} * { box-sizing: border-box; } body { overflow-x: hidden; margin: 0; }`}</style>
    </div>
  );
}
