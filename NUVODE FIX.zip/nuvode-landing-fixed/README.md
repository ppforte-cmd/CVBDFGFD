# Nuvode Landing Page - Setup Instructions

## Quick Start

1. **Extract this folder** to your computer

2. **Open terminal** in this folder and run:
```bash
npm install
```

3. **Start the dev server:**
```bash
npm start
```

Your site will open at `http://localhost:3000`

## Deploy to Vercel

1. **Make sure Git is initialized:**
```bash
git init
git add .
git commit -m "Initial commit"
```

2. **Push to GitHub** (create a repo on github.com first):
```bash
git remote add origin https://github.com/YOUR_USERNAME/nuvode-landing.git
git branch -M main
git push -u origin main
```

3. **Deploy with Vercel CLI:**
```bash
npm install -g vercel
vercel --prod
```

4. **Add your domain** in Vercel dashboard (Settings → Domains)

## Folder Structure

```
nuvode-landing-fixed/
├── public/
│   └── index.html          (HTML with font loaded)
├── src/
│   └── App.js              (Fixed React component)
├── package.json            (Dependencies)
└── README.md               (This file)
```

## What Was Fixed

- Moved Google Fonts link to `public/index.html` (proper place for fonts)
- Removed inline `<link>` tags from React component
- Moved global styles to bottom of component
- This makes it deployable to Vercel without errors

## Questions?

If `npm install` or `npm start` fails:
- Make sure you have Node.js installed (node.js.org)
- Delete `node_modules` folder and try `npm install` again
- Check your terminal for specific error messages
